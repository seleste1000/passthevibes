//
//  main.swift
//  HW02
//
//  Created by Braddock, Seleste on 8/26/15.
//  Copyright (c) 2015 Braddock, Seleste. All rights reserved.
//

import Foundation

//Write a program that prompts a user for the current month and 
//year and for a month and year in the past. The program should 
//output how far in the past the past date is.

//user inputs past month and year
//convert each entry to an int
print("Enter past month: ")
let pastMonth = console_input().toInt()!

print("Enter past year: ")
let pastYear = console_input().toInt()!

//user inputs current month and year
//convert each entry to an int
print("Enter current month: ")
var currentMonth = console_input().toInt()!

print("Enter current year: ")
var currentYear = console_input().toInt()!


//initialize variables for the total time in years and months
var timeYears = 0
var timeMonths = 0

//guards against inaccurate count of years and months
if pastMonth > currentMonth {
    
    timeYears = pastYear - currentYear - 1 //calculates number of years between past and present
    timeMonths = (12 - pastMonth) + (currentMonth) //calculates number of months between past and present
    
}
else {
    timeYears = pastYear - currentYear //calculates number of years between past and present
    timeMonths = currentMonth - pastMonth //calculates number of months between past and present
}



println("\(pastMonth)-\(pastYear) was \(timeYears) year(s), \(timeMonths) month(s) ago.")


