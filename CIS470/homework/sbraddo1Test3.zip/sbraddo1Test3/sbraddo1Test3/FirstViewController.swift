//
//  FirstViewController.swift
//  sbraddo1Test3
//
//  Created by Seleste Braddock on 11/24/15.
//  Copyright © 2015 Seleste Braddock. All rights reserved.
//

import UIKit



class FirstViewController: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var nameEntry: UITextField!
    
    @IBOutlet weak var monthEntry: UITextField!
    
    @IBOutlet weak var yearEntry: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.nameEntry.delegate = self
        self.monthEntry.delegate = self
        self.yearEntry.delegate = self
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    } //pressing return closes the keyboard
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    @IBAction func nameField(sender: AnyObject) {
        
        userName = self.nameEntry.text!
        
    }
    
    @IBAction func monthField(sender: AnyObject) {
        
        userMonth = self.monthEntry.text!
        
    }
    
    @IBAction func yearField(sender: AnyObject) {
        
        userYear = self.yearEntry.text!
        
    }
    
    

}

    