//
//  SecondViewController.swift
//  sbraddo1Test3
//
//  Created by Seleste Braddock on 11/24/15.
//  Copyright © 2015 Seleste Braddock. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    var ms = Int(userMonth)! ?? -1
    var ys = Int(userYear)! ?? -1
    
    @IBOutlet weak var greetings: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if ms < 1 {
            greetings.text = "Error. Try again"
        } else {
            if ys < 1 {
                greetings.text = "Error. Try again"
            }else{
                var userAge = age(ms, year: ys)
                
                greetings.text = "Hi \(userName)! You were born on \(ms)/\(ys), which was \(userAge.years) years and \(userAge.months) months ago!"
            }
        }
        

    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //unwrap

    
    
    
    @IBAction func genGreeting(sender: AnyObject) {
        
        //use age function
        if ms < 1 {
            greetings.text = "Error. Try again"
        } else {
            if ys < 1 {
                greetings.text = "Error. Try again"
            }else{
                var userAge = age(ms, year: ys)
                
                greetings.text = "Hi \(userName)! You were born on \(ms)/\(ys), which was \(userAge.years) years and \(userAge.months) months ago!"
            }
        }
    }
    
    
    
    //input validation
    
    
    
    
}


