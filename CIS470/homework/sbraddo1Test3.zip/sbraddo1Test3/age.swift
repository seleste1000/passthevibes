//
//  today.swift
//  today
//
//  Created by Jerry Volcy on 11/19/15.
//  Copyright (c) 2015 Spelman College. All rights reserved.
//

import Foundation



/* This function returns today's date as a tuple of integers.  day has a range
of 1 to 31.  month has a range of 1 to 12 and year is a positive integer. */
func today() -> (day:Int, month:Int, year:Int)
{
    //swift 1.1
    //let flags: NSCalendarUnit = .DayCalendarUnit | .MonthCalendarUnit | .YearCalendarUnit
    
    //swift 1.2
    let flags: NSCalendarUnit = [.NSDayCalendarUnit, .NSMonthCalendarUnit, .NSYearCalendarUnit]
    
    
    
    let date = NSDate()
    let components = NSCalendar.currentCalendar().components(flags, fromDate: date)
    
    let year:Int = components.year
    let month:Int = components.month
    let day:Int = components.day
    
    return (day, month, year)
}

/* This function returns the number of years and months that have passed.  It uses
the today() function to get today's year and month.  The user must supply the past
year and month of interest. */
func age(month:Int, year:Int) -> (months:Int, years:Int)
{
    var dataGood = true    //assume good data
    
    let x = today()
    
    //now check for valid data
    if month < 1 || month > 12
    {
        dataGood = false
    }
    
    if year < 1
    {
        dataGood = false
    }
    
    if x.month < 1 || x.month > 12
    {
        dataGood = false
    }
    
    if x.year < year
    {
        dataGood = false
    }

    if (dataGood == true)
    {
        var yearsAgo:Int        //var to store diff in years
        var monthsAgo:Int       //var to store diff in months
        //do the math to calculate yearsAgo and mothsAgo
        if month > x.month
        {
            yearsAgo = x.year - year - 1
            monthsAgo = 12 + x.month - month
        }
        else
        {
            yearsAgo = x.year - year
            monthsAgo = x.month - month
        }

        return (monthsAgo, yearsAgo)
    }
    else
    {
        return (0, 0)
    }
}