//
//  ThirdViewController.swift
//  sbraddo1HW18
//
//  Created by Seleste Braddock on 11/17/15.
//  Copyright © 2015 Seleste Braddock. All rights reserved.
//

import UIKit

class ThirdViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}