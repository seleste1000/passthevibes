//
//  main.swift
//  sbraddo1HW06
//
//  Created by Braddock, Seleste on 9/11/15.
//  Copyright (c) 2015 Braddock, Seleste. All rights reserved.
//

import Foundation



//Write a program that prompts a user for the current month and
//year and for a month and year in the past. The program should
//output how far in the past the past date is. 

//Eliminate all forced unwrapping of optionals.


//Past Month
//entry is saved as an optional int
print("Enter past month: ")
var pastMonthEntry : Int?
pastMonthEntry = console_input().toInt()

//unwrapping optional int using nil coalescing
let pastMonth = pastMonthEntry ?? 0

//input verification
if pastMonth <= 12 && pastMonth >= 1 {
    println(pastMonth)
    println("Valid input!")
}
else{
    println("Invalid entry :(")
}

//Past Year
//entry is saved as an optional int
print("Enter past year: ")
var pastYearEntry : Int?
pastYearEntry = console_input().toInt()

//unwrap optional int using nil coalescing 
let pastYear = pastYearEntry ?? 0

//input varification
if pastYear > 0 {
    println(pastYear)
    println("Valid input!")
}
else{
    println("Invalid entry :(")
}

//Current Month
//entry is saved as an optional int
print("Enter current month: ")
var currentMonthEntry : Int?
currentMonthEntry = console_input().toInt()

//unwrap optional int using nil coalescing
let currentMonth = currentMonthEntry ?? 0

if currentMonth <= 12 && currentMonth >= 1{
    println(currentMonth)
    println("Valid input!")
}
else{
    println("Invalid entry :(")
}

//Current year
//entry is saved as an optional int
print("Enter current year: ")
var currentYearEntry : Int?
currentYearEntry = console_input().toInt()

//unwrap optional using nil coalescing 
let currentYear = currentYearEntry ?? 0

if currentYear > 0 {
    println(currentYear)
    println("Valid input!")
}
else{
    println("Invalid entry :(")
}

//initialize variables for the total time in years and months
var timeYears = 0
var timeMonths = 0

//guards against inaccurate count of years and months
if pastMonth > currentMonth {
    
    timeYears = currentYear - pastYear - 1 //calculates number of years between past and present
    timeMonths = (12 - pastMonth) + (currentMonth) //calculates number of months between past and present
    
}
else {
    timeYears = currentYear - pastYear //calculates number of years between past and present
    timeMonths = currentMonth - pastMonth //calculates number of months between past and present
}



println("\(pastMonth)-\(pastYear) was \(timeYears) year(s), \(timeMonths) month(s) ago.")


