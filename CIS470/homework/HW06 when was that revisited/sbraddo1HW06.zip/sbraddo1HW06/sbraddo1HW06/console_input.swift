//
//  console_input.swift
//  console_input
//
//  Created by Jerry Volcy on 6/7/15.
//  Copyright (c) 2015 Spelman College. All rights reserved.
//

import Foundation

/* This function reads and returns a string from the standard input stream. */
func console_input() -> String
{
    //obtain a handle for the standard input stream (the keyboard)
    var keyboard = NSFileHandle.fileHandleWithStandardInput()
    
    //retrieve any available data from the input stream
    var inputData = keyboard.availableData
    var strData = NSString(data: inputData, encoding: NSUTF8StringEncoding)!

    //strip the CRLF from the string
    return strData.stringByTrimmingCharactersInSet(NSCharacterSet.newlineCharacterSet())
}
