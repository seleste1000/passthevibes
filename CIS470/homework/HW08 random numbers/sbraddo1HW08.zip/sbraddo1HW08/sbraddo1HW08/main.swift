

//
//  main.swift
//  sbraddo1HW08
//
//  Created by Braddock, Seleste on 9/18/15.
//  Copyright (c) 2015 Braddock, Seleste. All rights reserved.
//


import Foundation

var count = 0		//initialize variable to count loops

var x : Int         //initialize int to find 50

do{

	x = Int(arc4random_uniform(100))	//cast random number to an int
    println(x)

	count++                 //increase count of tested numbers


}while (x != 50)		//continues until x is 50



println("The number 50 took \(count) tries to find!!")