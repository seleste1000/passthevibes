//
//  ViewController.swift
//  sbraddo1Quiz5
//
//  Created by Seleste Braddock on 11/3/15.
//  Copyright © 2015 Seleste Braddock. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var val1: UILabel!
    
    @IBOutlet weak var val2: UILabel!
    
    @IBAction func diceButton(sender: AnyObject) {
        
        let x = Int(arc4random_uniform(6)+1)	//cast random number to an int
        let y = Int(arc4random_uniform(6)+1)	//cast random number to an int
        //print(x)
        
        val1.text = "\(x)"
        val2.text = "\(y)"
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

