//
//  main.swift
//  HW04
//
//  Created by Braddock, Seleste on 8/26/15.
//  Copyright (c) 2015 Braddock, Seleste. All rights reserved.
//

//User inputs a date in MM/DD/YYYY format.
//Print the date in a "Month day, Year" format
//


import Foundation


println("Enter a date (MM/DD/YYYY)")

//user inputs date (as one string)
var dateInput = console_input()


//separate dateInput string into an array
//MM, DD, YYYY values are recognized by their separation with "/"
var dateComponents = dateInput.componentsSeparatedByString("/")


//get MM value from array and change month value to an int
var MM = dateComponents[0].toInt()

//get DD value from array
var DD = dateComponents[1]

//get YYYY value from array
var YYYY = dateComponents[2]

//dictionary containing 1...12 as keys and months as values
let monthsDict = [1: "January",2: "February",3: "March", 4: "April", 5: "May", 6: "June", 7: "July", 8: "August", 9: "September", 10: "October", 11: "November", 12:"December"]

//month will be value corresponding to MM key in dictionary
var month = monthsDict[(MM!)]

println("The date you entered is \(month) \(DD), \(YYYY).")