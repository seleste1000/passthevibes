//
//  executable.swift
//  HW12
//
//  Created by Seleste Braddock on 10/2/15.
//  Copyright © 2015 Seleste Braddock. All rights reserved.
//

import Foundation

//tests
//var trial1 = Int(arc4random_uniform(UInt32(22)) + 0)
//var trial2 = Int(arc4random_uniform(UInt32(22)) + 0)
//var trial3 = Int(arc4random_uniform(UInt32(22)) + 0)
//
//print(trial1)
//print(factorial(Double(150)))

var askAgain = true //bool to determine whether to ask the user for different input

repeat{ // runs at least once and then repeat the program only if the user wants to
    
    var user_numPicks : Int = 0 //initializes var to hold users number of picks
    
    var user_range : Int = 0    //initializes var to hold the users desired range

    print("Enter the amount of picks you want: ")
    
    var user_numPicks_entry : Int?  //initializing optional int that holds user input
    
    user_numPicks_entry = Int(console_input())      //creates an optional var that stores user's range

    if var z = user_numPicks_entry { //unwrapping the optional int z and storing it in user_numPicks
    
        user_numPicks = z
        
        if user_numPicks < 1 {        //input validation
            //number of picks must be a positive number
        
            print("This is an invalid input!!! Try that again")
            
            askAgain = true //the input was invalid so the user will be asked if they want to try again
        
        } else {    //the user's input was valid
        
            askAgain = false    //the user's input was valid so they won't be automatically asked again
            
            print(user_numPicks)
            
            print("Enter a range for your quick picks: ")
            
            var user_range_entry : Int? = Int(console_input())      //creates an optional var that stores user's range
            
            if var y = user_range_entry { //unwrapping the optional int y and storing it in user_range
            
                user_range = y
                
                if user_range < user_numPicks {        //input validation
                    // user range cant be less than the amount of picks the user wants
                
                    print("This is an invalid input!!! Try that again")
                    
                    askAgain = true //the user will be asked if they want to try again
                
                } else{ // if the user's input has been completely valid so far
                
                    askAgain = false    //the user's input has all been valid so the program won't repeat unless the user chooses to do so
                    
                    print(user_range)
                }
            
            } else {    //if the optional couldnt be properly unwrapped
            
                askAgain = true //the user's input was invalid so they will be asked if they want to try again
                
                print("That input is invalid!")
            
            }
        
        }
    
    } else {    // if the optional can't be properly unwrapped
    
        askAgain = true     //the users input was invalid, they will be asked if they want to try again
        
        print("That input is invalid!")
    
    }

    

    if askAgain == false {  //if the users input has been valid
    
        var userPicks = QuickPicks()    //creates the QuickPicks() object
        
        userPicks.range = user_range    //sets the value of the range member variable
        userPicks.numPicks = user_numPicks  //sets the value of the numPicks member variable
        
        print("With the range of 1 to \(userPicks.range), your \(userPicks.numPicks) picks are...")
        
        var userPicksArray = userPicks.generatePicks()  //generates the users picks
        
        print(userPicksArray)   //prints the users picks

        var userWinningOdds = userPicks.getWinningOdds()    // holds the users odds of winning
        
        print("Your odds of winning are 1 in \(userWinningOdds)")   //prints the users odds of winning
        
        print("Do you want to find more Quick Picks? (y/n)")    //asks the user if they want to run the program again
        
        var askAgain_entry = console_input()    //takes in the users inputs
        
        if askAgain_entry.lowercaseString == "y" {  //if the user indicates yes with Y or y
        
            askAgain = true //the program will run again
        
        } else {   //if the user doesnt say yes
        
            askAgain = false    //exits the program
            
            print("Bye!")
        
        }
    
    } else {    //if the user's input is invalid
    
        print("Do you want to try again? (y/n)")    //asks the user if they want to run the program again
        
        var askAgain_entry = console_input()    //takes in the users response
        
        if askAgain_entry.lowercaseString == "y" {  //if the user inputs y or Y
        
            askAgain = true //the program will run again
        
        } else {   //if the user doesnt say yes
        
            askAgain = false    //the program will not continue
        
            print("Bye!")
        }
    }

}while (askAgain == true)   //program continues until user indicates that they wish to exit

// tests
// var testAgain = QuickPicks()
// testAgain.numPicks = 12
// testAgain.range = 56
// print(testAgain.generatePicks())
// print(testAgain.getWinningOdds())



