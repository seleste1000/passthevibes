//
//  main.swift
//  HW05
//
//  Created by Braddock, Seleste on 9/3/15.
//  Copyright (c) 2015 Braddock, Seleste. All rights reserved.
//

import Foundation

//Assume that another part of the code has supplied //you with the following two tuple constants:

let tupPoint1 = (5.094, 4.761)
let tupPoint2 = (8.238, 2.150)
//Now, create tupMidPoint, the tuple that will hold //the x,y coordinates of the mid-point
//Mid-point formula: ( (x2 - x1)/2 , (y1 - y2)/2 )

//tupPoint1 = (x1, y1)      
//tupPoint2 = (x2, y2)

//get x and y  using indices

var x1 = tupPoint1.0
var y1 = tupPoint1.1

var x2 = tupPoint2.0
var y2 = tupPoint2.1

//Now printout the coordinates of tupMidPoint

var xMidpt = ( x2 - x1 ) / 2

var yMidpt = ( y2 - y1 ) / 2

println("The midpoint between \(tupPoint1) and \(tupPoint2) is ( \(xMidpt) , \(yMidpt) )")



