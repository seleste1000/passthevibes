//
//  ViewController.swift
//  HW16
//
//  Created by Seleste Braddock on 10/20/15.
//  Copyright © 2015 Seleste Braddock. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var circVal: UILabel! //circumference
    
    func circumference(r: Double?) -> Double { //calculates circumference
        
        let c = r!*M_PI*2
        
        circVal.text = "\(c)" //changes circumference label text
        
        return c //returns circumference
    }
    
    @IBOutlet weak var areaVal: UILabel! //area label
    
    func area(r: Double?) -> Double { //calculates area
        
        let a = r!*r!*M_PI
        
        areaVal.text = "\(a)" //changes area label output
        
        return a //returns area
    }
    
    
    @IBOutlet weak var radiusOutput: UILabel! //radius label
    
    var radiusCounter : Double = 0 //will be used to change radius output
    
    //var downCount : Int = 0
    //var upCount : Int = 0

    @IBAction func upButton(sender: AnyObject) {
        
        radiusCounter += 0.1
        
        radiusOutput.text = "\(radiusCounter)"
        
        circumference(radiusCounter)
        area(radiusCounter)
        
        //upCount++
        
    }
    @IBAction func downButton(sender: AnyObject) {
        
        if radiusCounter > 0 {
            
            radiusCounter -= 0.1
            
            if radiusCounter < 0.1 {
                radiusOutput.text = "0.0"
                radiusCounter = 0.0
            } else {
    
            radiusOutput.text = "\(radiusCounter)"
            }
            
            circumference(radiusCounter)
            area(radiusCounter)
            //downCount++
            
        } /*else {
            //do nothing
            //can I make this have an error beep?
        }*/
        
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

