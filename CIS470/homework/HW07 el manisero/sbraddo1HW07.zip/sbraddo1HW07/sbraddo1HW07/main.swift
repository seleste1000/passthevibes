//
//  main.swift
//  sbraddo1HW07
//
//  Created by Braddock, Seleste on 9/18/15.
//  Copyright (c) 2015 Braddock, Seleste. All rights reserved.
//

import Foundation
var price : Double
var menuRepeat = false
var peanuts : Double

do {
    println("Enter amount in peanuts (in lbs:)")
    var x : Int? = console_input().toInt()      //creates an optional var that stores amount of peanuts
    
    if var y = x { //unwrapping the optional int x and storing it in peanuts
        peanuts = Double(y)
        if peanuts < 0 {        //input validation
            println("This is an invalid input!!! Try that again")
            menuRepeat = true
        }
        switch peanuts {
            case 0...10:
                price = peanuts * 0.35
                println("The cost of \(peanuts) lbs of peanuts is $\(price)")
            case 11...50:
                price = peanuts * 0.25
                println("The cost of \(peanuts) lbs of peanuts is $\(price)")
        case 51...100:
                price = peanuts * 0.15
                println("The cost of \(peanuts) lbs of peanuts is $\(price)")
            default:
                price = peanuts * 0.10
                println("The cost of \(peanuts) lbs of peanuts is $\(price)")
                    }
        menuRepeat = false
        }
    else{
        println("Your input was invalid :( Try again!")
        menuRepeat = true
        }


} while menuRepeat


