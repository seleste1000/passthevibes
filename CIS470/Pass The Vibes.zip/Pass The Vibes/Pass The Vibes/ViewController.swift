//
//  ViewController.swift
//  pass the vibes
//
//  Created by Jaycee Hermida Holmes on 10/18/15.
//
//  Copyright (c) 2015 Jaycee Holmes All rights reserved.


import UIKit
import Parse
import ParseUI
import Bolts

class ViewController: UIViewController, UIImagePickerControllerDelegate {
    
    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var tempImageView: UIImageView!
    
    var lastPoint = CGPoint.zero // stores the last drawn point on the canvas
    var red: CGFloat = 0.0 // color red
    var green: CGFloat = 0.0 // color green
    var blue: CGFloat = 0.0 // color blue
    var brushWidth: CGFloat = 10.0 // width of the brush stroke
    var opacity: CGFloat = 1.0 // opacity of the brush stroke
    var swiped = false // was the brush stroke continuous
    
    
    // Acknowledge that a touch just began
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) { // func that deals with first touch
        swiped = false // has not yet swiped
        if let touch = touches.first { // if touch event occured, let first touch be entered into set
            lastPoint = touch.locationInView(self.view) // make first touch location = last point touched
        }
    }
    
    // drawLineFrom
    func drawLineFrom(fromPoint: CGPoint, toPoint: CGPoint) {// func that draw lines
        
        // 1
        UIGraphicsBeginImageContext(view.frame.size) // view, frame, size?? where is this coming from?
        let context = UIGraphicsGetCurrentContext() // get context for temp Image view?
        tempImageView.image?.drawInRect(CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height)) // create temp Image View rectangle
        
        // 2
        CGContextMoveToPoint(context, fromPoint.x, fromPoint.y) // starts path at point specified
        CGContextAddLineToPoint(context, toPoint.x, toPoint.y) // ends path at point specified
        
        // 3
        CGContextSetLineCap(context, CGLineCap.Round) // sets style of end point
        CGContextSetLineWidth(context, brushWidth) // sets brush width
        CGContextSetRGBStrokeColor(context, red, green, blue, 1.0) // sets color
        CGContextSetBlendMode(context, CGBlendMode.Normal) // sets how Quartz composites sample values for a graphics context
        
        // 4
        CGContextStrokePath(context) // draws path
        
        // 5
        tempImageView.image = UIGraphicsGetImageFromCurrentImageContext() // returns image
        tempImageView.alpha = opacity // sets opacity
        UIGraphicsEndImageContext() // stops getting image context
        
    }
    
    // touches moved
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) { // func that determines how the touches moved
        
        // 6
        swiped = true // continuous stroke
        if let touch = touches.first { // mkake new touch first touch in set
            let currentPoint = touch.locationInView(view) // update current point
            drawLineFrom(lastPoint, toPoint: currentPoint) //draw the line from the last point to the current point
            
            // 7
            lastPoint = currentPoint // update last point
        }
    }
    
    
    // so there is a do-while loop that is in progress where the condition is whether or not the screen is being touched. The drawing happens point to point on the temp view image, but it happens so quickly that it is seemingly continuous
    
    
    
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) { // function for the offical last point
        
        if !swiped { // if swipe is not continuous
            // draw a single point
            drawLineFrom(lastPoint, toPoint: lastPoint) // draw a single point
        }
        
        // Merge tempImageView into mainImageView
        UIGraphicsBeginImageContext(mainImageView.frame.size) // call the main image view of frame and size specified in storyboard
        mainImageView.image?.drawInRect(CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height), blendMode: CGBlendMode.Normal, alpha: 1.0) // properties of the image in main image view
        tempImageView.image?.drawInRect(CGRect(x: 0, y: 0, width: view.frame.size.width, height: view.frame.size.height), blendMode: CGBlendMode.Normal, alpha: opacity) // properties of image in temp image view
        mainImageView.image = UIGraphicsGetImageFromCurrentImageContext() // getting the image from the current context (temp image view) and assigning it to main view
        UIGraphicsEndImageContext() // stop calling the main image view
        
        tempImageView.image = nil // clear temp image view so that it can begin again
    }
    
    let colors: [(CGFloat, CGFloat, CGFloat)] = [ // defining the ten colors on the screen
        (0, 0, 0),
        (105.0 / 255.0, 105.0 / 255.0, 105.0 / 255.0),
        (1.0, 0, 0),
        (0, 0, 1.0),
        (51.0 / 255.0, 204.0 / 255.0, 1.0),
        (102.0 / 255.0, 204.0 / 255.0, 0),
        (102.0 / 255.0, 1.0, 0),
        (160.0 / 255.0, 82.0 / 255.0, 45.0 / 255.0),
        (1.0, 102.0 / 255.0, 0),
        (1.0, 1.0, 0),
        (1.0, 1.0, 1.0),
    ]
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        if segue.identifier == "settingsSegue"{
            let settingsViewController = segue.destinationViewController as! SettingsViewController
            settingsViewController.delegate = self
            settingsViewController.brush = brushWidth
            settingsViewController.opacity = opacity
            settingsViewController.red = red
            settingsViewController.green = green
            settingsViewController.blue = blue
        }
        if segue.identifier == "postSegue"{
            let composeViewController = segue.destinationViewController as! ComposeViewController
            composeViewController.toPass = mainImageView.image
            
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Actions
    @IBAction func post(sender: AnyObject) {
        
    }
    
    @IBAction func reset(sender: AnyObject) { // function that resets main image to white background
        mainImageView.image = nil // // when touched resets main image to white background
        
    }
    
    @IBAction func pencilPressed(sender: AnyObject) { // function that changes the color when a pencil is pressed
        
        var index = sender.tag ?? 0 // either the object was touched or it was not
        if index < 0 || index >= colors.count { // if touch was out of range, invalid
            index = 0 // color is black
        }
        
        
        (red, green, blue) = colors[index] // if touch was valid, then color becomes whatever index was set to the tag of the image
        
        
        if index == colors.count - 1 { // if index is equal to the eraser tag
            opacity = 1.0 // make sure opacity is at full because this is intended for erasing
        }
    }
}

extension ViewController: SettingsViewControllerDelegate {
    func settingsViewControllerFinished(settingsViewController: SettingsViewController) {
        self.brushWidth = settingsViewController.brush
        self.opacity = settingsViewController.opacity
        self.red = settingsViewController.red
        self.green = settingsViewController.green
        self.blue = settingsViewController.blue
        
    }
}