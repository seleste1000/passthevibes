//
//  ComposeViewController.swift
//  Pass The Vibes
//
//  Created by Seleste Braddock on 12/7/15.
//  Copyright © 2015 Seleste and Jaycee!. All rights reserved.
//

import Foundation
import UIKit
import Parse
import Bolts

class ComposeViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate, UIPickerViewDelegate {

    @IBOutlet weak var caption: UITextView!
    @IBOutlet weak var drawing: UIImageView!
    @IBOutlet weak var postedBy: UITextView!
    
    
    @IBOutlet weak var moodPicker: UIPickerView!
    
    //picker data
    //let pickerData : UIPickerViewDataSource = ["Happy", "Confident", "Relaxed", "Confused", "Excited", "In Love", "Scared", "Lonely", "Stressed", "Angry", "Neutral", "Sad"]
    
    var toPass: UIImage!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //edit postedBy (get User)
        postedBy.text = PFUser.currentUser()?.username
        //edit imageview
        drawing.image = toPass
    }
    

    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        
        
        if segue.identifier == "cancelSegue"{
            // delete photo
        }
        
   if segue.identifier == "postPhotoSegue"{
    let photoToUpload = PFObject(className: "Posts")
    
    photoToUpload.saveInBackgroundWithBlock({(success: Bool, error: NSError?) -> Void in
        
        if error == nil {
            
            // uploading the image
            let imageToBeUploaded = self.drawing.image
            let imageData = UIImagePNGRepresentation(imageToBeUploaded!)!
            let imagefile = PFFile(name:"image.png", data:imageData)! //parse file
            photoToUpload["Images"] = imagefile
            photoToUpload.saveInBackgroundWithBlock({(success: Bool, error: NSError?) -> Void in
                
                if error == nil {
                    //success
                } else {
                    print(error)
                }
            })
            
            
            
        } else {
            print(error)
        }
        
        
    }
        )
    
//
       }

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backPressed(sender: AnyObject) {
        
        let drawvc: AnyObject? = self.storyboard?.instantiateViewControllerWithIdentifier("DrawVC")  //creates a reference to drawvc (the drawing view controller)
        
        self.presentViewController(drawvc as! UIViewController, animated: true, completion: nil) //presents the drawing screen
    }
    
    @IBAction func cancelPressed(sender: AnyObject) {
        
        //return to feed
        
        
    }
    
    
    @IBAction func postPressed(sender: AnyObject) {
        
        
        // post photo to database

        
        
        // post mood to database
        // post username to database
        
        
    }
    
    
    
    
    
}