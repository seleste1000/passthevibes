//
//  SignUpViewController.swift
//  Pass The Vibes
//
//  Created by Seleste Braddock on 12/6/15.
//  Copyright © 2015 Seleste and Jaycee!. All rights reserved.
//

import Foundation

import UIKit
import Parse
import Bolts

class SignUpViewController: UIViewController, UITextFieldDelegate {
    
    //text fields
    @IBOutlet weak var usernameField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    @IBOutlet weak var emailField: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        self.usernameField.delegate = self
        self.passwordField.delegate = self
        self.emailField.delegate = self
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    } //pressing return closes the keyboard
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    
    @IBAction func signupTapped(sender: AnyObject) {
        
        let user = PFUser()
        user.username = usernameField.text
        user.password = passwordField.text
        user.email = emailField.text
        
        user.signUpInBackgroundWithBlock({
            (succeeded: Bool, error: NSError?) -> Void in
            
            if error == nil {
                //There was no error.
                
                print("Successfully Signed Up User.")
                
                let vc: UIViewController = (self.storyboard?.instantiateViewControllerWithIdentifier("LoginVC"))!
                
                self.presentViewController(vc, animated: true, completion: nil)
                
            } else {
                //There were one ore more errors while signing up the user.
                
                //creates an alert controller and displays it
                
                let alertController = UIAlertController(title: "Error", message: "There was one or more errors while signing up.", preferredStyle: UIAlertControllerStyle.Alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .Cancel, handler: nil))
                
                self.presentViewController(alertController, animated: true, completion: nil)
                
            } //end if-else error checking
            
        }) //end user creation closure
        
    } //end signupTapped button
    
    
    //button to take the user to the login screen
    @IBAction func toLoginScreen(sender: AnyObject) {
        
        let signupvc: AnyObject? = self.storyboard?.instantiateViewControllerWithIdentifier("LoginVC")  //creates a reference to signupvc (the sign in view controller)
        
        self.presentViewController(signupvc as! UIViewController, animated: true, completion: nil) //presents the sign in screen
        
    }
    
    
    

}
