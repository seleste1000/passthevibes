//
//  PostTableViewCell.swift
//  Swiftagram
//
//  Created by Parth Saxena on 7/2/15.
//  Copyright (c) 2015 Parth Saxena. All rights reserved.
//

import UIKit
import Parse
import ParseUI
import Bolts

class FeedTableViewCell: UITableViewCell {

    @IBOutlet weak var postImageView: PFImageView!
    @IBOutlet weak var postCaption: UILabel!
    @IBOutlet weak var addedBy: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
