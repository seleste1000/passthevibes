//
//  ProfileViewController.swift
//  Pass The Vibes
//
//  Created by Seleste Braddock on 12/6/15.
//  Copyright © 2015 Seleste and Jaycee!. All rights reserved.
//

import Foundation
import UIKit
import Parse
import Bolts


class ProfileViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

