//
//  LoginViewController.swift
//  Pass The Vibes
//
//  Created by Seleste Braddock on 12/6/15.
//  Copyright © 2015 Seleste and Jaycee!. All rights reserved.
//

import Foundation
import UIKit
import Parse
import Bolts

class LoginViewController: UIViewController, UITextFieldDelegate {
    
    //text fields
    @IBOutlet weak var usernameField: UITextField! //username
    @IBOutlet weak var passwordField: UITextField! //password
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        self.usernameField.delegate = self
        self.passwordField.delegate = self
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: "dismissKeyboard")
        view.addGestureRecognizer(tap)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    } //pressing return closes the keyboard
    
    //Calls this function when the tap is recognized.
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    
    //Log In! button connects to the tab view controller called "TabVC" if the login is correct
    @IBAction func loginTapped(sender: AnyObject) {
        
        let username = usernameField.text
        let password = passwordField.text
        
        PFUser.logInWithUsernameInBackground(username!, password: password!) { //built in Parse function that checks if a user exists
            
            //check to see whether username and password are valid
            (user: PFUser?, error: NSError?) -> Void in
            
            if (user != nil) {
                //Successfully Logged in.
                
                print("Successfully Logged In.")
                
                let navvc: AnyObject? = self.storyboard?.instantiateViewControllerWithIdentifier("NavVC")  //creates a reference to tabvc (the tab view controller)
                
                self.presentViewController(navvc as! UIViewController, animated: true, completion: nil) //presents the tab view controller as a regular view on its first responder
                
            } else {
                //Error while logging in.
                
                //displaying a pop-up alert
                let alertController = UIAlertController(title: "Error", message: "Error, Incorrect Username/Password.", preferredStyle: UIAlertControllerStyle.Alert) //creates an alert controller that displays an error message
                
                alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Cancel, handler: nil)) //gives a pop-up alert message
                
                self.presentViewController(alertController, animated: true, completion: nil) //presenting the alert controller
                
            } //if-else: checks for error
            
        } //end error checking function
        
    } //close loginTapped button
    
    
    //Sign up here button takes the user to the SignUpVC so that they can enter their information
    @IBAction func signupTapped(sender: AnyObject) {
        
        let signupvc: AnyObject? = self.storyboard?.instantiateViewControllerWithIdentifier("SignUpVC")  //creates a reference to signupvc (the sign in view controller)
        
        self.presentViewController(signupvc as! UIViewController, animated: true, completion: nil) //presents the sign in screen
        
        
    }
    
    
    
}
