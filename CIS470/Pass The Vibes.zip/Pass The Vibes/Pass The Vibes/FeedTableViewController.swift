
//
//  FeedTableViewController.swift
//  Pass The Vibes
//
//  Created by Seleste Braddock on 12/6/15.
//  Copyright © 2015 Seleste and Jaycee!. All rights reserved.
//

import UIKit
import Parse
import ParseUI
import Bolts


class FeedTableViewController: UITableViewController {
    
    var images = [PFFile]() // images
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // refresh
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: Selector("refreshPulled"), forControlEvents: UIControlEvents.ValueChanged)
        
        loadData()
        self.tableView.reloadData()
        
    }
    
    func refreshPulled() { // refresh screen
        
        loadData()
        
        self.tableView.reloadData()
        
        refreshControl?.endRefreshing()
        
    }
    
    func loadData() {
        
        let query = PFQuery(className: "Posts")
        query.orderByDescending("createdAt")
        query.findObjectsInBackgroundWithBlock {
            (objects: [PFObject]?, error: NSError?)  -> Void in
            
            if error == nil {
                // The find succeeded.
                // print("Successfully retrieved \(objects!.count) scores.")
                // Do something with the found objects
                if let posts = objects {
                    for post in posts {
                        
                        if let nextImage = post["Images"] as! PFFile? {
                            self.images.append(nextImage)
                        } else {
                            print("couldn't unwrap image")
                        }
                        
                    }
                    
                    self.tableView.reloadData()
                    
                }
            } else {
                // Log details of the failure
                // print("Error: \(error!) \(error!.userInfo)")
            }
            
        }
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Potentially incomplete method implementation.
        // Return the number of sections.
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete method implementation.
        if images.count == 0 {
            return 0
        } else {
            return images.count
        }
        // Return the number of rows in the section.
        //return images.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("FeedCell", forIndexPath: indexPath) as! FeedTableViewCell
        // Configure the cell...
        
        let imageToLoad = images[indexPath.row] as PFFile
        
        do{
            let imageData = try imageToLoad.getData()
            let finalizedImage = UIImage(data: imageData)
            cell.postImage.image = finalizedImage
            
        }catch{
            print("error")
        }
        
        
        
        return cell
    }

    
}

