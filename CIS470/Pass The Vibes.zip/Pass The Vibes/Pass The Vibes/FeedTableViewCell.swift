//
//  FeedTableViewCell.swift
//  Pass The Vibes
//
//  Created by Seleste Braddock on 12/7/15.
//  Copyright © 2015 Seleste and Jaycee!. All rights reserved.
//

import UIKit
import Parse
import ParseUI
import Bolts

class FeedTableViewCell: UITableViewCell {
    
    @IBOutlet weak var postImage: UIImageView!
    @IBOutlet weak var addedBy: UITextView!

    //@IBOutlet weak var postImageView: PFImageView!
    //@IBOutlet weak var postCaption: UILabel!
    //@IBOutlet weak var addedBy: UILabel!
    //@IBOutlet weak var dateLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}